This archive contains a small CSV for TW10.
